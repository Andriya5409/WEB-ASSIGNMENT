<?php
// Assignment 2: reads data.json and serves it as JSON (data only, no HTML)
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$file = __DIR__ . '/data.json';
if (!is_readable($file)) { http_response_code(500); echo json_encode(['error' => 'Data file not found']); exit; }
$data = json_decode(file_get_contents($file), true);
if (!is_array($data) || !isset($data['graph'])) { http_response_code(500); echo json_encode(['error' => 'Invalid data file']); exit; }
echo json_encode($data, JSON_UNESCAPED_UNICODE);
