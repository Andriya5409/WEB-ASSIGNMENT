const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LABEL={Lesson:'Format',Quiz:'Size',Scholarship:'Deadline',Student:'Progress',Teacher:'Teaches'};
let items=[],pool=[],auth=false,typeSel='All',localSearch=true;
const setStatus=h=>{$('#status').innerHTML=h};

// Flat "graph" array -> view models (resolve linked ids to names)
function build(graph,extra=graph){
  const by=Object.fromEntries([...extra,...graph].map(n=>[n.id,n]));
  return graph.map(n=>({...n,linkNames:(n.links||[]).map(id=>by[id]?.name||id)}));
}
function card(n){
  return `<article class="card">
    <p class="meta"><span class="badge">${esc(n.type)}</span> ${esc(n.category)}</p>
    <h3>${esc(n.name)}</h3>
    <p>${esc(n.description)}</p>
    ${n.detail?`<p><strong>${esc(LABEL[n.type]||'Detail')}:</strong> ${esc(n.detail)}</p>`:''}
    ${n.linkNames.length?`<p><strong>Related:</strong> ${esc(n.linkNames.join(', '))}</p>`:''}
    <ul class="tags">${(n.tags||[]).map(t=>`<li${t==='At risk'?' class="risk"':''}>${esc(t)}</li>`).join('')}</ul>
    ${auth?`<button data-edit="${esc(n.id)}">Edit</button>`:''}
  </article>`;
}
function chips(){
  const ts=['All',...new Set((pool.length?pool:items).map(n=>n.type))];
  $('#chips').innerHTML=ts.map(t=>`<button class="chip${t===typeSel?' on':''}" data-type="${esc(t)}">${esc(t)}</button>`).join('');
}
function render(list){
  $('#results').innerHTML=list.map(card).join('');
  $('#empty').hidden=list.length>0;
  $('#count').textContent=`(${list.length})`;
}
// type filter always; text filter only when searching on the client (Assignments 1 and 2)
function filter(){
  const q=$('#search').value.trim().toLowerCase();
  render(items.filter(n=>(typeSel==='All'||n.type===typeSel)&&(!localSearch||!q||
    JSON.stringify([n.name,n.type,n.description,n.category,n.detail,n.tags,n.linkNames]).toLowerCase().includes(q))));
}
$('#chips').onclick=e=>{const t=e.target.dataset.type;if(t){typeSel=t;chips();filter();}};

// ---- Assignment 3: everything goes through the REST API ----
localSearch=false;                       // search happens on the server
let all=[],cats=[],timer,seq=0,editId=null;

async function api(path,method='GET',body){
  const r=await fetch('api/'+path,{method,credentials:'same-origin',headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});
  const j=await r.json().catch(()=>({}));
  if(!r.ok)throw Object.assign(new Error(j.error||'HTTP '+r.status),{status:r.status});
  return j;
}
async function load(){
  const my=++seq,q=$('#search').value.trim();
  setStatus('Loading...');
  try{
    const j=await api('items'+(q?'?q='+encodeURIComponent(q):''));
    if(my!==seq)return;
    if(!q){all=j.graph;items=pool=build(all);try{localStorage.setItem('tc_cache',JSON.stringify(all));}catch(_){}}else items=build(j.graph,all);
    setStatus('');chips();filter();
  }catch(e){
    if(my!==seq)return;
    setStatus(`Failed to load data (${esc(e.message)}). <button id="retry">Retry</button>`);
    let c=null;try{c=JSON.parse(localStorage.getItem('tc_cache'));}catch(_){}
    if(c){all=c;items=pool=build(c);chips();filter();setStatus('Offline: showing the last saved copy (read-only). <button id="retry">Retry</button>');}
    $('#retry').onclick=load;
  }
}
function setAuth(v){
  auth=v;$('#addBtn').hidden=!v;
  $('#loginBtn').textContent=v?'Logout':'Login';
  filter();
}
function openForm(n){
  editId=n?n.id:null;
  const f=$('#projForm'),E=f.elements;
  f.reset();$('#projErr').textContent='';
  $('#projTitle').textContent=n?'Edit entry':'Add entry';
  $('#catSel').innerHTML=cats.map(l=>`<option value="${l.id}">${esc(l.name)}</option>`).join('');
  $('#linkSel').innerHTML=all.filter(x=>x.id!==editId).map(x=>`<option value="${esc(x.id)}">${esc(x.name)} (${esc(x.type)})</option>`).join('');
  if(n){
    for(const k of ['type','name','description','detail'])E[k].value=n[k]||'';
    const o=[...E.category.options].find(o=>o.text===n.category);if(o)E.category.value=o.value;
    E.tags.value=(n.tags||[]).join(', ');
    [...E.links.options].forEach(o=>o.selected=(n.links||[]).includes(o.value));
  }
  $('#projDlg').showModal();
}
$('#loginBtn').onclick=async()=>{
  if(auth){await api('logout','POST');setAuth(false);}
  else{$('#loginErr').textContent='';$('#loginDlg').showModal();}
};
$('#loginForm').onsubmit=async e=>{
  e.preventDefault();
  try{await api('login','POST',Object.fromEntries(new FormData(e.target)));$('#loginDlg').close();setAuth(true);}
  catch(x){$('#loginErr').textContent=x.message;}
};
$('#addBtn').onclick=()=>openForm(null);
$('#results').onclick=e=>{const id=e.target.dataset.edit;if(id)openForm(items.find(n=>n.id===id));};
$('#projForm').onsubmit=async e=>{
  e.preventDefault();
  const E=e.target.elements;
  const b={type:E.type.value,name:E.name.value,description:E.description.value,category:+E.category.value,detail:E.detail.value,
    tags:E.tags.value.split(','),links:[...E.links.selectedOptions].map(o=>o.value)};
  try{
    await api(editId?'items/'+editId:'items',editId?'PUT':'POST',b);
    $('#projDlg').close();$('#search').value='';
    await load();                       // refresh the UI without a page reload
  }catch(x){
    if(x.status===401){$('#projDlg').close();setAuth(false);}
    $('#projErr').textContent=x.message;
  }
};
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>b.closest('dialog').close());
$('#search').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(load,250);});
(async()=>{
  try{auth=(await api('session')).loggedIn;cats=(await api('categories')).categories;}catch(e){}
  $('#addBtn').hidden=!auth;$('#loginBtn').textContent=auth?'Logout':'Login';
  load();
})();
