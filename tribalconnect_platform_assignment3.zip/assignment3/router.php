<?php
// Used only with: php -S localhost:8000 router.php
$p = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (strpos($p, '/api/') === 0) { require __DIR__ . '/api/index.php'; return true; }
return false;
