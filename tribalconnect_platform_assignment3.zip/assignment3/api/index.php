<?php
require __DIR__ . '/../db.php';
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();
header('Content-Type: application/json; charset=utf-8');

function out(int $code, $data) { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
function gid(string $p, $n) { return sprintf('%s-%03d', $p, $n); }
function num($v) { return (int)preg_replace('/\D/', '', (string)$v); }

const TYPES = ['Lesson', 'Quiz', 'Scholarship', 'Student', 'Teacher'];

// Builds the {"graph":[...]} structure from the database tables
function graph(PDO $pdo, string $q): array {
    $l = "%$q%";
    $s = $pdo->prepare('SELECT DISTINCT i.*, l.name AS cat FROM items i
        JOIN categories l ON l.id = i.category_id
        LEFT JOIN item_tags t ON t.item_id = i.id
        WHERE i.name LIKE ? OR i.description LIKE ? OR i.detail LIKE ? OR l.name LIKE ? OR t.tag LIKE ?
        ORDER BY i.id');
    $s->execute([$l, $l, $l, $l, $l]);
    $tags = []; foreach ($pdo->query('SELECT item_id, tag FROM item_tags ORDER BY id') as $r) $tags[$r['item_id']][] = $r['tag'];
    $links = []; foreach ($pdo->query('SELECT k.item_id, k.linked_id, i.type FROM item_links k JOIN items i ON i.id = k.linked_id') as $r)
        $links[$r['item_id']][] = gid(strtolower($r['type']), $r['linked_id']);
    $g = [];
    foreach ($s as $i) $g[] = ['id' => gid(strtolower($i['type']), $i['id']), 'type' => $i['type'], 'name' => $i['name'],
        'description' => $i['description'], 'category' => $i['cat'], 'detail' => $i['detail'],
        'tags' => $tags[$i['id']] ?? [], 'links' => $links[$i['id']] ?? []];
    return $g;
}

// Validates the request body; sends 400 on bad input
function clean(array $b): array {
    $ty = $b['type'] ?? ''; $n = trim($b['name'] ?? ''); $d = trim($b['description'] ?? '');
    $cat = (int)($b['category'] ?? 0); $det = trim($b['detail'] ?? '');
    if (!in_array($ty, TYPES, true) || $n === '' || $d === '' || $cat < 1 || strlen($n) > 150 || strlen($det) > 255)
        out(400, ['error' => 'Invalid or missing fields']);
    $tags = array_values(array_unique(array_filter(array_map('trim', array_map('strval', (array)($b['tags'] ?? []))))));
    $links = array_values(array_unique(array_filter(array_map('num', (array)($b['links'] ?? [])))));
    return [$ty, $n, $d, $cat, $det, $tags, $links];
}

function save(PDO $pdo, ?int $id, array $c): int {
    [$ty, $n, $d, $cat, $det, $tags, $links] = $c;
    $pdo->beginTransaction();
    if ($id === null) {
        $pdo->prepare('INSERT INTO items (type, name, description, category_id, detail) VALUES (?,?,?,?,?)')->execute([$ty, $n, $d, $cat, $det]);
        $id = (int)$pdo->lastInsertId();
    } else {
        $pdo->prepare('UPDATE items SET type=?, name=?, description=?, category_id=?, detail=? WHERE id=?')->execute([$ty, $n, $d, $cat, $det, $id]);
        $pdo->prepare('DELETE FROM item_tags WHERE item_id=?')->execute([$id]);
        $pdo->prepare('DELETE FROM item_links WHERE item_id=?')->execute([$id]);
    }
    foreach ($tags as $t) $pdo->prepare('INSERT INTO item_tags (item_id, tag) VALUES (?,?)')->execute([$id, $t]);
    foreach ($links as $k) if ($k !== $id) $pdo->prepare('INSERT INTO item_links (item_id, linked_id) VALUES (?,?)')->execute([$id, $k]);
    $pdo->commit();
    return $id;
}

$m = $_SERVER['REQUEST_METHOD'];
$seg = explode('/', trim(preg_replace('#^.*?/api/?#', '', parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH)), '/'));
$in = json_decode(file_get_contents('php://input'), true);
if (!is_array($in)) $in = [];
$auth = !empty($_SESSION['uid']);

try {
    switch ($seg[0]) {
        case 'session':
            out(200, ['loggedIn' => $auth]);
        case 'login':
            if ($m !== 'POST') out(405, ['error' => 'Method not allowed']);
            $s = $pdo->prepare('SELECT id FROM users WHERE username = ? AND password = ?');
            $s->execute([(string)($in['username'] ?? ''), (string)($in['password'] ?? '')]);
            if (!($u = $s->fetch())) out(401, ['error' => 'Invalid username or password']);
            session_regenerate_id(true);
            $_SESSION['uid'] = $u['id'];
            out(200, ['ok' => true]);
        case 'categories':
            out(200, ['categories' => $pdo->query('SELECT id, name FROM categories ORDER BY name')->fetchAll()]);
        case 'logout':
            session_destroy();
            out(200, ['ok' => true]);
        case 'items':
            if ($m === 'GET') out(200, ['graph' => graph($pdo, trim($_GET['q'] ?? ''))]);
            if (!$auth) out(401, ['error' => 'Login required']);
            if ($m === 'POST') out(201, ['id' => save($pdo, null, clean($in))]);
            if ($m === 'PUT') {
                $id = num($seg[1] ?? '');
                $s = $pdo->prepare('SELECT 1 FROM items WHERE id = ?');
                $s->execute([$id]);
                if (!$id || !$s->fetch()) out(404, ['error' => 'Entry not found']);
                out(200, ['id' => save($pdo, $id, clean($in))]);
            }
            out(405, ['error' => 'Method not allowed']);
        default:
            out(404, ['error' => 'Not found']);
    }
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    if ($e->getCode() === '23000') out(400, ['error' => 'Invalid category or related entry']);
    error_log($e->getMessage());
    out(500, ['error' => 'Server error']);
}
