CREATE DATABASE IF NOT EXISTS tribal_connect CHARACTER SET utf8mb4;
USE tribal_connect;
CREATE TABLE categories (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB;
CREATE TABLE items (id INT AUTO_INCREMENT PRIMARY KEY, type ENUM('Lesson','Quiz','Scholarship','Student','Teacher') NOT NULL,
  name VARCHAR(150) NOT NULL, description TEXT NOT NULL, category_id INT NOT NULL, detail VARCHAR(255) NOT NULL DEFAULT '',
  FOREIGN KEY (category_id) REFERENCES categories(id)) ENGINE=InnoDB;
CREATE TABLE item_tags (id INT AUTO_INCREMENT PRIMARY KEY, item_id INT NOT NULL, tag VARCHAR(50) NOT NULL,
  FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE item_links (item_id INT NOT NULL, linked_id INT NOT NULL, PRIMARY KEY (item_id, linked_id),
  FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE, FOREIGN KEY (linked_id) REFERENCES items(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE, password VARCHAR(100) NOT NULL) ENGINE=InnoDB;

INSERT INTO categories VALUES (1,'Class 10'),(2,'Class 9'),(3,'English'),(4,'Mathematics'),(5,'Scholarship'),(6,'Science');
INSERT INTO items VALUES
(1,'Lesson','Fractions and Decimals','Introductory lesson with worked examples in Malayalam and English, available as a low-bitrate video for offline use.',4,'Video, 12 min, 18 MB offline pack'),
(2,'Lesson','Plants and Photosynthesis','How plants make food, explained with diagrams and a short PDF summary.',6,'PDF and video, 15 min'),
(3,'Lesson','Simple English Conversation','Everyday spoken English practice with audio narration and subtitles.',3,'Audio, 10 min'),
(4,'Quiz','Fractions Quiz','Auto-scored quiz on fractions and decimals; questions are drafted by AI and approved by the teacher.',4,'10 questions, 20 marks'),
(5,'Quiz','Photosynthesis Quiz','Short quiz with instant feedback and badges for good scores.',6,'8 questions, 16 marks'),
(6,'Scholarship','Post-Matric Scholarship for ST Students','Financial support for Scheduled Tribe students continuing studies after Class 10. Check eligibility and gather the documents before applying.',5,'2026-12-31'),
(7,'Scholarship','Pre-Matric Scholarship for ST Students','Support for Scheduled Tribe students in Classes 9 and 10 for books, fees and other expenses.',5,'2026-11-30'),
(8,'Student','Anu K','Learns offline and syncs progress when online. Doing well across subjects.',2,'Attendance 92%, average score 78%'),
(9,'Student','Bindu M','Missed several lessons; needs extra help with fractions.',2,'Attendance 64%, average score 41%'),
(10,'Student','Manu P','Regular attendance; practising spoken English.',1,'Attendance 88%, average score 71%'),
(11,'Teacher','Smt. Lakshmi R','Uploads lessons, creates quizzes and monitors student progress.',4,'Mathematics, Class 9'),
(12,'Teacher','Sri. Joseph T','Uploads lessons, approves AI-drafted quizzes and answers doubts.',6,'Science, Class 9'),
(13,'Teacher','Smt. Fathima S','Prepares audio-narrated English lessons with subtitles.',3,'English, Class 10');
INSERT INTO item_tags (item_id,tag) VALUES (1,'Malayalam'),(1,'English'),(1,'Offline'),(1,'Class 9'),(2,'English'),(2,'Offline'),(2,'Class 9'),(3,'English'),(3,'Audio narration'),(3,'Subtitles'),(3,'Class 10'),(4,'Auto-scored'),(4,'Teacher approved'),(5,'Auto-scored'),(5,'Badges'),(6,'ST students'),(6,'Caste certificate'),(6,'Income certificate'),(6,'Bank passbook'),(7,'ST students'),(7,'Caste certificate'),(7,'School certificate'),(8,'On track'),(9,'At risk'),(9,'Weak topic: Fractions'),(10,'On track'),(11,'Teacher'),(12,'Teacher'),(13,'Teacher');
INSERT INTO item_links VALUES (1,11),(2,12),(3,13),(4,1),(5,2),(8,1),(8,4),(8,7),(9,1),(9,4),(10,3),(10,6);
INSERT INTO users (username,password) VALUES ('admin','admin123');
