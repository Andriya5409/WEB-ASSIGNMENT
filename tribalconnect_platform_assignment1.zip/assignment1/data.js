const DATA = {
  "graph": [
    {
      "id": "lesson-001",
      "type": "Lesson",
      "name": "Fractions and Decimals",
      "description": "Introductory lesson with worked examples in Malayalam and English, available as a low-bitrate video for offline use.",
      "category": "Mathematics",
      "detail": "Video, 12 min, 18 MB offline pack",
      "tags": [
        "Malayalam",
        "English",
        "Offline",
        "Class 9"
      ],
      "links": [
        "teacher-011"
      ]
    },
    {
      "id": "lesson-002",
      "type": "Lesson",
      "name": "Plants and Photosynthesis",
      "description": "How plants make food, explained with diagrams and a short PDF summary.",
      "category": "Science",
      "detail": "PDF and video, 15 min",
      "tags": [
        "English",
        "Offline",
        "Class 9"
      ],
      "links": [
        "teacher-012"
      ]
    },
    {
      "id": "lesson-003",
      "type": "Lesson",
      "name": "Simple English Conversation",
      "description": "Everyday spoken English practice with audio narration and subtitles.",
      "category": "English",
      "detail": "Audio, 10 min",
      "tags": [
        "English",
        "Audio narration",
        "Subtitles",
        "Class 10"
      ],
      "links": [
        "teacher-013"
      ]
    },
    {
      "id": "quiz-004",
      "type": "Quiz",
      "name": "Fractions Quiz",
      "description": "Auto-scored quiz on fractions and decimals; questions are drafted by AI and approved by the teacher.",
      "category": "Mathematics",
      "detail": "10 questions, 20 marks",
      "tags": [
        "Auto-scored",
        "Teacher approved"
      ],
      "links": [
        "lesson-001"
      ]
    },
    {
      "id": "quiz-005",
      "type": "Quiz",
      "name": "Photosynthesis Quiz",
      "description": "Short quiz with instant feedback and badges for good scores.",
      "category": "Science",
      "detail": "8 questions, 16 marks",
      "tags": [
        "Auto-scored",
        "Badges"
      ],
      "links": [
        "lesson-002"
      ]
    },
    {
      "id": "scholarship-006",
      "type": "Scholarship",
      "name": "Post-Matric Scholarship for ST Students",
      "description": "Financial support for Scheduled Tribe students continuing studies after Class 10. Check eligibility and gather the documents before applying.",
      "category": "Scholarship",
      "detail": "2026-12-31",
      "tags": [
        "ST students",
        "Caste certificate",
        "Income certificate",
        "Bank passbook"
      ],
      "links": []
    },
    {
      "id": "scholarship-007",
      "type": "Scholarship",
      "name": "Pre-Matric Scholarship for ST Students",
      "description": "Support for Scheduled Tribe students in Classes 9 and 10 for books, fees and other expenses.",
      "category": "Scholarship",
      "detail": "2026-11-30",
      "tags": [
        "ST students",
        "Caste certificate",
        "School certificate"
      ],
      "links": []
    },
    {
      "id": "student-008",
      "type": "Student",
      "name": "Anu K",
      "description": "Learns offline and syncs progress when online. Doing well across subjects.",
      "category": "Class 9",
      "detail": "Attendance 92%, average score 78%",
      "tags": [
        "On track"
      ],
      "links": [
        "lesson-001",
        "quiz-004",
        "scholarship-007"
      ]
    },
    {
      "id": "student-009",
      "type": "Student",
      "name": "Bindu M",
      "description": "Missed several lessons; needs extra help with fractions.",
      "category": "Class 9",
      "detail": "Attendance 64%, average score 41%",
      "tags": [
        "At risk",
        "Weak topic: Fractions"
      ],
      "links": [
        "lesson-001",
        "quiz-004"
      ]
    },
    {
      "id": "student-010",
      "type": "Student",
      "name": "Manu P",
      "description": "Regular attendance; practising spoken English.",
      "category": "Class 10",
      "detail": "Attendance 88%, average score 71%",
      "tags": [
        "On track"
      ],
      "links": [
        "lesson-003",
        "scholarship-006"
      ]
    },
    {
      "id": "teacher-011",
      "type": "Teacher",
      "name": "Smt. Lakshmi R",
      "description": "Uploads lessons, creates quizzes and monitors student progress.",
      "category": "Mathematics",
      "detail": "Mathematics, Class 9",
      "tags": [
        "Teacher"
      ],
      "links": []
    },
    {
      "id": "teacher-012",
      "type": "Teacher",
      "name": "Sri. Joseph T",
      "description": "Uploads lessons, approves AI-drafted quizzes and answers doubts.",
      "category": "Science",
      "detail": "Science, Class 9",
      "tags": [
        "Teacher"
      ],
      "links": []
    },
    {
      "id": "teacher-013",
      "type": "Teacher",
      "name": "Smt. Fathima S",
      "description": "Prepares audio-narrated English lessons with subtitles.",
      "category": "English",
      "detail": "English, Class 10",
      "tags": [
        "Teacher"
      ],
      "links": []
    }
  ]
};
