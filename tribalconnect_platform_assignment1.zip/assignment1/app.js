const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LABEL={Lesson:'Format',Quiz:'Size',Scholarship:'Deadline',Student:'Progress',Teacher:'Teaches'};
let items=[],pool=[],auth=false,typeSel='All',localSearch=true;
const setStatus=h=>{$('#status').innerHTML=h};

// Flat "graph" array -> view models (resolve linked ids to names)
function build(graph,extra=graph){
  const by=Object.fromEntries([...extra,...graph].map(n=>[n.id,n]));
  return graph.map(n=>({...n,linkNames:(n.links||[]).map(id=>by[id]?.name||id)}));
}
function card(n){
  return `<article class="card">
    <p class="meta"><span class="badge">${esc(n.type)}</span> ${esc(n.category)}</p>
    <h3>${esc(n.name)}</h3>
    <p>${esc(n.description)}</p>
    ${n.detail?`<p><strong>${esc(LABEL[n.type]||'Detail')}:</strong> ${esc(n.detail)}</p>`:''}
    ${n.linkNames.length?`<p><strong>Related:</strong> ${esc(n.linkNames.join(', '))}</p>`:''}
    <ul class="tags">${(n.tags||[]).map(t=>`<li${t==='At risk'?' class="risk"':''}>${esc(t)}</li>`).join('')}</ul>
    ${auth?`<button data-edit="${esc(n.id)}">Edit</button>`:''}
  </article>`;
}
function chips(){
  const ts=['All',...new Set((pool.length?pool:items).map(n=>n.type))];
  $('#chips').innerHTML=ts.map(t=>`<button class="chip${t===typeSel?' on':''}" data-type="${esc(t)}">${esc(t)}</button>`).join('');
}
function render(list){
  $('#results').innerHTML=list.map(card).join('');
  $('#empty').hidden=list.length>0;
  $('#count').textContent=`(${list.length})`;
}
// type filter always; text filter only when searching on the client (Assignments 1 and 2)
function filter(){
  const q=$('#search').value.trim().toLowerCase();
  render(items.filter(n=>(typeSel==='All'||n.type===typeSel)&&(!localSearch||!q||
    JSON.stringify([n.name,n.type,n.description,n.category,n.detail,n.tags,n.linkNames]).toLowerCase().includes(q))));
}
$('#chips').onclick=e=>{const t=e.target.dataset.type;if(t){typeSel=t;chips();filter();}};

// ---- Assignment 1: data comes from data.js (const DATA) ----
$('#search').addEventListener('input',filter);
items=build(DATA.graph);
chips();filter();
